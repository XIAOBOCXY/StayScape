# StayScape 余宿成景

StayScape 是面向酒店临期客房的文旅业务系统：FastAPI + PostgreSQL 保存真实经营数据，确定性规则计算库存、成本、售价、毛利和状态；ECS 上唯一的 OpenClaw Agent 负责 Skill 编排、产品候选和营销内容。ClawHive 只发布、展示和验证 Skill，不承担线上业务调用。

## 产品定位

- 酒店临期库存驱动的文旅产品生成与动态运营
- 酒店自然语言运营任务：经营者在 Web 或飞书提出目标，生成待确认产品候选，再明确加入草稿或发布
- 酒店产品工作台：可先选博物馆、亲子乐园、双人约会等产品方向与人数套餐；AI 按实时库存生成多套候选，支持批量自然语言改稿与单品细调
- 游客端只浏览酒店已发布产品、提交预约意向，并保留“问一问”轻量咨询；不再提供多日自主组包
- Web/H5 和飞书共用一个 OpenClaw Gateway、一个 Agent：`stayscape-main`
- ClawHive 仅用于 Skill 发布、管理、验证和展示；不作为 StayScape 的运行时 API

```text
Visitor H5  -> FastAPI -> OpenClaw -> stayscape-main -> stayscape-visitor-matcher (问一问)
Hotel Web   -> FastAPI -> OpenClaw -> stayscape-main -> Product/Marketing Skills -> 待确认候选
Feishu      -> OpenClaw Feishu Channel -> stayscape-main -> StayScape Tools -> 待确认候选 -> 明确确认草稿/发布
```

## 核心演示不变量

演示 Seed 始终保留：亲子房 6 间、家庭早餐 30 份、延迟退房 6 份、室内非遗手作 12 个名额；每套消耗 1/3/1/3，因此最终可售 4 套。成本为 `220 + 15×3 + 10 + 60×3 = 455` 元，建议售价 599 元，单套毛利 144 元，毛利率约 24.04%。商户把手作名额改为 4 后，产品自动变为 1 套并进入 `LOW_STOCK`。

## 本地 Windows 开发

```powershell
Copy-Item .env.example .env
python -m venv .venv
.venv\Scripts\python.exe -m pip install -r apps/server/requirements.txt
.venv\Scripts\python.exe -m alembic -c apps/server/alembic.ini upgrade head
.venv\Scripts\python.exe scripts/seed_demo.py

# Terminal 1
.venv\Scripts\python.exe -m uvicorn app.main:app --app-dir apps/server --reload --port 8000

# Terminal 2
npm.cmd --prefix apps/web install --cache apps/web/.npm-cache
npm.cmd --prefix apps/web run dev
```

访问 `http://localhost:5173`；API 文档为 `http://localhost:8000/docs`。默认酒店账号为 `hotel_demo / StayScape123!`，商户账号示例为 `merchant_craft / StayScape123!`。

## Docker Demo

无需模型密钥即可演示完整业务闭环：

```bash
cp .env.example .env
bash scripts/deploy.sh demo
```

Windows 若已安装 Docker Desktop，也可以执行 `docker compose up -d --build`，入口默认是 `http://localhost:8080`。

## 阿里云公网 Live 部署

在 Ubuntu 22.04/24.04 或阿里云 Linux ECS 上：

```bash
git clone https://github.com/XIAOBOCXY/StayScape.git
cd StayScape
cp .env.example .env
# 在 .env 中填写模型供应商配置；飞书凭证可选
bash scripts/deploy.sh live
```

### 下载后在哪里填写 API 和密钥

所有密钥只填写在**项目根目录的本机 `.env` 文件**中：

- 下载 ZIP 后：先解压，再进入同时包含 `README.md` 和 `.env.example` 的解压目录；API 填在该目录的 `.env`
- 本地克隆后：`<项目根目录>/.env`
- 部署到 ECS 后：`/opt/StayScape/.env`

例如，下载 ZIP 后请在解压目录执行；不要在 GitHub 网页、前端页面或任何源码文件中填写 Key：

```bash
cd <解压后的 StayScape 目录>
cp .env.example .env
nano .env
```

先从模板创建并限制权限：

```bash
cd /opt/StayScape
cp .env.example .env
chmod 600 .env
nano .env
```

当前仓库固定 OpenClaw `2026.6.9`，并在项目的 Qwen Standard 模型目录中显式声明了 `qwen/qwen3.5-plus` 与 `qwen/qwen3.7-plus`。Live 实际使用的主对话模型只读取服务器 `.env` 中的 `OPENCLAW_PRIMARY_MODEL`；无需修改 Compose、脚本或代码；它需要阿里云百炼的 **Standard 按量** API Key。当前默认用 3.5-plus 进行联调，稳定后可只改这一项切回 3.7-plus。

使用 Qwen + OpenClaw 的 Live 模式时，填写以下配置；`QWEN_API_KEY` 替换为你自己在阿里云百炼创建的真实 Standard API Key：

```env
MODE=live
AGENT_PROVIDER=openclaw
OPENCLAW_BASE_URL=http://openclaw:18789
OPENCLAW_AGENT_TARGET=openclaw/default
OPENCLAW_PRIMARY_MODEL=qwen/qwen3.5-plus
QWEN_API_KEY=<你的百炼 Standard API Key>
FEISHU_ENABLED=false
```

### 可选：百炼 Wan AI 配图

SVG 海报中的文字继续由本站的 SVG 排版生成，便于编辑并避免 AI 文字失真；需要新的主视觉时，再由经营端点击“生成宣传素材”并勾选 AI 视觉配图。每次操作只请求 1 张图，不会在 Seed、部署或游客浏览时自动调用。

在同一个服务器 `.env` 中追加（`WAN_IMAGE_API_KEY` 留空即可复用上面的 Standard Key）：

```env
WAN_IMAGE_ENABLED=true
WAN_IMAGE_MODEL=wan2.7-image
WAN_IMAGE_WORKSPACE_ID=<你的百炼 Workspace ID>
WAN_IMAGE_REGION=cn-beijing
WAN_IMAGE_API_KEY=
WAN_IMAGE_SIZE=1536*2048
WAN_IMAGE_WATERMARK=true
```

Wan 2.7 使用与 API Key 同地域的工作空间地址，程序会根据 `WAN_IMAGE_WORKSPACE_ID` 与 `WAN_IMAGE_REGION` 自动拼出官方接口；不需要填写或维护 `WAN_IMAGE_API_URL`。模型也只由 `WAN_IMAGE_MODEL` 这一项控制：想从 `wan2.7-image` 切到 `wan2.7-image-pro` 时，只改服务器 `.env` 后重新部署，页面和接口都不能覆盖该选择。百炼返回的临时图片链接会在服务器上下载保存到 `runtime/generated-media/`；该目录和 `.env` 都被 Git 忽略。浏览器只会拿到本站的图片地址，不会拿到百炼 Key、Qwen Key 或临时供应商链接。图像生成按成功图片数计费，请在生产前确认你的百炼价格与余额。

飞书不是 Web/H5 的启动前置条件。如需启用飞书，再在同一个 `.env` 中填写：`FEISHU_APP_ID`、`FEISHU_APP_SECRET`、`FEISHU_DM_ALLOW_FROM`、`FEISHU_GROUP_ALLOW_FROM`、`FEISHU_GROUP_SENDER_ALLOW_FROM`、`FEISHU_OPERATOR_ALLOW_FROM` 和 `FEISHU_SUPPORT_ALLOW_FROM`。

不要把真实 Qwen Key、飞书 Secret、Gateway Token、Tool Token 或数据库密码写进 README、源码、前端、Dockerfile、Skill ZIP，或提交到 GitHub。项目的 `.gitignore` 会排除 `.env`；部署脚本会在服务器端生成 `SECRET_KEY`、PostgreSQL 密码、Gateway Token 和 Tool Token。

脚本会生成服务端密钥、PostgreSQL 密码、Gateway Token 和 Tool Token，构建 PostgreSQL、FastAPI、Vue、Nginx 以及固定版本的官方 OpenClaw 镜像，安装四个 Skill（包含余宿成景酒店运营总控 Skill）、Qwen provider、可选 Feishu plugin 和 StayScape Tool Plugin，执行迁移、幂等 Seed、健康检查、Skill/plugin discovery、模型清单检查和一次真实 `/v1/responses` smoke test。Live 模式需要把 `QWEN_API_KEY` 预先写入服务器 `.env`；模型供应商首次授权仍需人工完成一次。

公网只开放 80/443；不要开放 18789、5432、8000。详细步骤见 [docs/DEPLOY_ALIYUN.md](docs/DEPLOY_ALIYUN.md)、[docs/OPENCLAW.md](docs/OPENCLAW.md) 和 [docs/FEISHU.md](docs/FEISHU.md)。

## 测试与打包

```powershell
.venv\Scripts\python.exe -m pytest apps/server/tests -q
npm.cmd --prefix apps/web run build
.venv\Scripts\python.exe scripts/package_skills.py
```

四个 ZIP 位于 `dist/`，分别对应余宿成景运营总控、产品生成、游客问一问和营销文案 Skill；ZIP 根目录直接包含 `SKILL.md`，打包脚本会排除 `.env`、密钥、`node_modules`、缓存和构建产物。

## 目录

- `apps/server`：FastAPI、SQLAlchemy、Alembic、规则引擎、Agent 编排和业务 API
- `apps/web`：酒店 Web、商户端和游客 H5
- `skills`：四个可上传 ClawHive 的 Skill，其中余宿成景可脱离 Web 平台运行本地确定性演示
- `integrations/stayscape-openclaw-plugin`：官方 OpenClaw Tool Plugin
- `deploy/openclaw`：固定版本 OpenClaw 容器和配置模板
- `scripts`：本地 Seed、Skill 打包、demo/live 一键部署
- `docs`：架构、赛题对齐、业务调研、测试案例、OpenClaw、飞书和阿里云部署说明
