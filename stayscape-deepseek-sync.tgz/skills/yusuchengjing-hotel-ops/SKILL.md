---
name: yusuchengjing-hotel-ops
description: Analyze this fixed Hangzhou hotel's near-term unsold rooms and create, recheck, or refresh human-approved cultural-travel product candidates from local facts and deterministic tools.
---

# 余宿成景：酒店临期库存文旅运营

## Purpose

This Skill serves one fixed Hangzhou hotel. Its job is to turn the hotel's
next 24 to 48 hours of unsold rooms into a small number of sellable,
human-reviewed cultural-travel product candidates. It is not a general
tour-planning, OTA-search, payment, or autonomous publishing Skill.

Read the fixed hotel profile at {baseDir}/references/hotel-profile.md before
using the local demonstration data. In the StayScape deployment, use the
allowlisted StayScape Tools first; they are the live source of truth. The
files under {baseDir}/data are a fully runnable, explicitly labelled
competition-test fallback for local demonstrations only.

## Non-negotiable rules

1. Never invent rooms, resource IDs, dates, opening hours, availability,
   prices, costs, margins, weather, bookings, source facts, or partner rights.
2. Use a live StayScape Tool result whenever it is available. Do not replace a
   failed Tool call with sample-data results without saying that the result is
   a local demonstration result.
3. Only hotel services and approved, AVAILABLE partner resources may become
   formal package rights. A public POI is a route recommendation only.
4. All capacity, cost, minimum legal price, margin, time, age, weather, and
   approval checks belong to deterministic tools. The model may not calculate
   or override their output.
5. A candidate that does not PASS validation is not a product. Do not produce
   finished sales copy, a poster, or a publish instruction for it.
6. Creating a candidate is not confirmation. In StayScape, create
   PENDING_CONFIRMATION candidates first. Add a candidate to draft or publish
   it only after the hotel operator explicitly says which action to take.
7. Never expose credentials, internal chain-of-thought, private guest data,
   hidden accounting, or database IDs in visitor-facing copy.

## Data and Tool contract

For a live hotel-operator conversation, use the tools in this order:

1. Call stayscape_analyze_hotel_opportunity with the requested date and any
   stated crowd, group-size, or theme constraints. It returns factual room
   opportunities, recent aggregate demand signals, weather provenance,
   eligible resources, and sourced public knowledge.
2. If a product is requested, call stayscape_create_product_proposal with a
   concise natural-language brief grounded in that result. Do not choose
   resource IDs yourself. FastAPI locks the actual selections, calculates
   capacity and finance, and creates only pending candidates.
3. If asked to recheck a date or an existing product after weather or resource
   changes, call stayscape_recheck_product_health. Report its resulting
   adjustment, substitute, or pause state faithfully.
4. If asked about a public place, call stayscape_search_travel_knowledge.
   Preserve source and verification status. A VERIFY_REQUIRED record must be
   labelled 信息需确认 and cannot become a formal package right.
5. If the operator says 加入草稿 or 确认发布 and identifies a current pending
   candidate, call stayscape_confirm_product_proposal. Ambiguous approval such
   as 可以 or 就这个 first requires a clarification.

For a portable local demonstration, use these files and scripts:

| Need | Data | Deterministic script |
| --- | --- | --- |
| Room pressure | {baseDir}/data/room_inventory.json | {baseDir}/scripts/analyze_inventory.py |
| Recent demand | {baseDir}/data/recent_sales.json | {baseDir}/scripts/analyze_demand.py |
| Eligible partners | {baseDir}/data/partner_resources.json | {baseDir}/scripts/search_resources.py |
| Package capacity | selected formal components | {baseDir}/scripts/calculate_capacity.py |
| Finance floor | selected formal components | {baseDir}/scripts/calculate_finance.py |
| Publish gate | candidate and all check snapshots | {baseDir}/scripts/validate_package.py |
| Substitute | failed partner resource and constraints | {baseDir}/scripts/find_substitute.py |
| Save reviewed result | {baseDir}/data/products.json | {baseDir}/scripts/save_product.py |

The complete local, deterministic demonstration is:

    python {baseDir}/scripts/run_workflow.py --date 2026-09-12 --count 2

## Main workflow

1. Resolve relative dates. If the date remains ambiguous, ask one short
   clarification; otherwise do not require the operator to repeat inventory.
2. Read factual room pressure, recent aggregate demand, latest weather and
   eligible partner resources. Explain the evidence as concise facts, not
   hidden reasoning.
3. Select one or two distinct candidate directions. They must differ by crowd,
   core experience, or purchase scene; never create cosmetic A/B duplicates.
4. Build each candidate around one room, one or two hotel services, and one
   primary approved partner experience. Avoid treating a one-night product as
   a packed tour group.
5. Calculate capacity and finance, then run the validator. On failure, repair
   according to the error code and validate again. Do not skip a failed check.
6. After PASS, create a one-night/two-day light route. Clearly separate
   formal included rights from public, non-bookable route suggestions.
7. Create product-detail copy, Moments copy, a Xiaohongshu-style seeding note,
   a 30-second video outline, poster brief, and poster prompt. Only use
   confirmed product facts.
8. Show the candidate and an auditable, brief evidence summary. Ask for the
   explicit next action: keep as pending, 加入草稿, or 确认发布.

## Validation, retry, and fallback

- CAPACITY_INSUFFICIENT: choose a compatible room/service/resource or lower
  the merchant-controlled listing ceiling, then recalculate.
- MARGIN_TOO_LOW: select a lower-cost non-core alternative or raise the
  suggested price to the deterministic minimum; do not hide a weak margin.
- TIME_CONFLICT: rotate to a non-overlapping approved session.
- WEATHER_MISMATCH: prefer a compatible indoor resource; if no substitute
  exists, pause the candidate.
- AGE_NOT_ALLOWED: remove the incompatible resource; never solve this only by
  editing copy.
- RESOURCE_NOT_APPROVED or RESOURCE_UNAVAILABLE: exclude it and use only a
  newly filtered substitute.
- MISSING_REQUIRED_DATA: do not create a formal candidate. Tell the operator
  exactly which fact must be maintained.
- Tool/network failure: say the live operation was not completed and offer a
  retry. Do not invent a result or silently downgrade to local test data.

## Route, marketing, and poster rules

Read {baseDir}/references/marketing-style.md and
{baseDir}/references/poster-rules.md before drafting content.

- Use exact supplied names, times, inclusions, and source-backed place facts.
- Do not use generic phrases such as 为你打造, 一站式, 沉浸式, 解锁, 邂逅,
  独特魅力, 精彩纷呈, or 满足多样化需求.
- Apply the locality substitution, real-operator, and adjective-removal checks
  in the marketing reference. Rewrite when a sentence passes all three tests
  too easily.
- A poster image is a visual brief or a generated image layer. Its text layer
  must be rendered from validated fields, not invented by an image model.
- Poster generation must not change product rights, price, capacity, status,
  or route facts.

## Dynamic update workflow

For an inventory, service, partner-capacity, or weather change:

1. Identify existing products that use the changed formal component.
2. Recalculate capacity, finance, and all validation gates from the new facts.
3. If the formal component fails and is replaceable, find a compatible
   approved substitute, then recalculate and validate again.
4. If no PASS result remains, pause the product and state the actionable
   reason. Never leave its old quantity or marketing material live.
5. When formal rights change, refresh detail copy, social copy, video outline,
   and poster brief from the validated product snapshot.

## Final output contract

For every PASS candidate, return a compact operator-facing result containing:

- target date, product name, target segment, purchase scenario, and status;
- formal room/service/partner rights, maximum sellable quantity, bottleneck,
  deterministic finance snapshot, and constraints;
- clearly separated public route suggestions with source and verification
  status;
- H5, Moments, Xiaohongshu, video, poster brief, and poster prompt;
- validation status, validation time, data-source notices, and the required
  human confirmation action.

Never show an unfinished candidate as published or visitor-bookable.
