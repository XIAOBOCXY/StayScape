"""StayScape backend application package."""

