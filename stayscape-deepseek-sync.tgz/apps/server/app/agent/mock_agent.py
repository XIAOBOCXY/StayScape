"""Deterministic offline Agent used by the demo and automated tests.

The mock creates creative candidates from the supplied resource metadata.  It
never owns inventory, pricing, margin or publication decisions; those remain
inside ProductService and the rules package.
"""

from __future__ import annotations

import json
from html import escape
from typing import Any


class MockAgent:
    """Local Agent contract with deterministic, theme-aware output."""

    PROFILE_RULES = {
        "THEME_PARK": {"key": "themepark", "label": "主题乐园", "suffix": "欢乐宿", "tag": "THEME PARK", "hashtags": "#杭州乐园 #亲子周末 #城市游乐"},
        "KIDS": {"key": "kids", "label": "儿童探索", "suffix": "儿童探索宿", "tag": "KIDS", "hashtags": "#杭州亲子游 #雨天去哪儿 #儿童乐园"},
        "NATURE": {"key": "nature", "label": "自然探索", "suffix": "自然探索宿", "tag": "NATURE", "hashtags": "#西溪湿地 #自然课堂 #杭州亲子游"},
        "SPORT": {"key": "sport", "label": "运动娱乐", "suffix": "运动挑战宿", "tag": "SPORT", "hashtags": "#杭州运动 #朋友周末 #想刺激一点"},
        "NIGHTLIFE": {"key": "nightlife", "label": "杭州夜游", "suffix": "夜游宿", "tag": "NIGHTLIFE", "hashtags": "#杭州夜游 #运河夜景 #城市夜生活"},
        "PHOTO": {"key": "photo", "label": "城市旅拍", "suffix": "旅拍宿", "tag": "PHOTO", "hashtags": "#杭州旅拍 #西湖夜景 #旅行记录"},
        "FOOD": {"key": "food", "label": "江南味觉", "suffix": "美食宿", "tag": "FOOD", "hashtags": "#杭帮菜 #杭州美食 #旅行吃什么"},
        "PERFORMANCE": {"key": "performance", "label": "城市演出", "suffix": "演出宿", "tag": "PERFORMANCE", "hashtags": "#杭州演出 #夜间文化 #城市周末"},
        "ENTERTAINMENT": {"key": "entertainment", "label": "城市娱乐", "suffix": "娱乐宿", "tag": "ENTERTAINMENT", "hashtags": "#杭州娱乐 #朋友出行 #夜间生活"},
        "CITY_WALK": {"key": "city_walk", "label": "城市漫游", "suffix": "漫游宿", "tag": "CITY WALK", "hashtags": "#杭州漫游 #城市散步 #一个人的旅行"},
        "CULTURE": {"key": "culture", "label": "杭州手作", "suffix": "文化宿", "tag": "CULTURE", "hashtags": "#杭州非遗 #亲子手作 #旅行灵感"},
        "TEA": {"key": "tea", "label": "茶香慢生活", "suffix": "茶旅宿", "tag": "TEA", "hashtags": "#杭州茶文化 #慢旅行 #茶空间"},
    }
    CROWD_LABELS = {
        "FAMILY": "亲子家庭",
        "COUPLE": "情侣与朋友",
        "FRIENDS": "朋友小组",
        "SOLO": "独自出发的旅行者",
        "LOCAL_WEEKEND": "杭州本地周末客",
    }

    def __init__(self, mode: str = "normal") -> None:
        self.mode = mode
        self.calls = 0

    def generate(self, skill_name: str, payload: dict[str, Any]) -> str:
        self.calls += 1
        if self.mode == "timeout":
            raise TimeoutError("mock agent timeout")
        if self.mode in {"invalid", "invalid_once"} and (self.mode == "invalid" or self.calls == 1):
            return "not-json"
        if skill_name == "stayscape-product-generator":
            return json.dumps(self._product(payload), ensure_ascii=False)
        if skill_name == "stayscape-marketing-writer":
            return json.dumps(self._marketing(payload), ensure_ascii=False)
        return json.dumps(self._visitor(payload), ensure_ascii=False)

    def repair_json(self, skill_name: str, payload: dict[str, Any], raw_response: str) -> str:
        if skill_name == "stayscape-product-generator":
            return json.dumps(self._product(payload), ensure_ascii=False)
        if skill_name == "stayscape-marketing-writer":
            return json.dumps(self._marketing(payload), ensure_ascii=False)
        return json.dumps(self._visitor(payload), ensure_ascii=False)

    @classmethod
    def _profile(cls, payload: dict[str, Any], partner: dict[str, Any]) -> dict[str, str]:
        category = str(partner.get("category", "")).upper()
        text = f"{payload.get('theme', '')} {partner.get('resource_name', '')} {partner.get('description', '')}".lower()
        aliases = (
            ("THEME_PARK", ("乐园", "主题公园", "themepark", "theme park")),
            ("KIDS", ("儿童乐园", "儿童探索", "kids")),
            ("SPORT", ("攀岩", "卡丁车", "射箭", "运动", "sport")),
            ("NIGHTLIFE", ("夜游", "夜景", "运河夜", "nightlife")),
            ("PHOTO", ("旅拍", "摄影", "照片", "photo")),
            ("FOOD", ("美食", "杭帮菜", "甜品", "咖啡", "烘焙", "food")),
            ("NATURE", ("自然", "湿地", "动物", "植物", "nature")),
            ("PERFORMANCE", ("演出", "剧场", "音乐现场", "performance")),
            ("ENTERTAINMENT", ("娱乐", "陶艺", "桌游", "密室", "vr")),
            ("CITY_WALK", ("漫游", "路线", "街巷", "city walk")),
            ("TEA", ("茶", "点茶", "tea")),
            ("CULTURE", ("非遗", "手作", "丝绸", "香囊", "文化", "craft")),
        )
        for key, words in aliases:
            if category == key or any(word in text for word in words):
                return cls.PROFILE_RULES[key]
        crowd = str(payload.get("target_crowd", "")).upper()
        return cls.PROFILE_RULES["KIDS" if crowd == "FAMILY" else "CITY_WALK"]

    @classmethod
    def _pick_partner(cls, payload: dict[str, Any], requested_ids: list[int], variant_index: int) -> dict[str, Any]:
        allowed = list(payload.get("allowed_partner_resources", []))
        pool = [item for item in allowed if item.get("id") in requested_ids] if requested_ids else allowed
        if not pool:
            return {}
        if requested_ids:
            return pool[variant_index % len(pool)]
        theme = str(payload.get("theme", "")).lower()
        crowd = str(payload.get("target_crowd", "")).upper()
        weather = str(payload.get("weather", "")).upper()

        def affinity(item: dict[str, Any]) -> tuple[int, int, int]:
            profile = cls._profile(payload, item)
            text = f"{profile['key']} {item.get('resource_name', '')} {item.get('description', '')}".lower()
            score = sum(5 for word in (theme, crowd.lower(), weather.lower()) if word and word in text)
            if weather == "RAIN" and item.get("indoor"):
                score += 3
            if weather != "RAIN" and not item.get("indoor"):
                score += 2
            return (-score, int(item.get("settlement_price", 0) or 0), int(item.get("id", 0)))

        return sorted(pool, key=affinity)[variant_index % len(pool)]

    @classmethod
    def _poster_svg(cls, *, profile: dict[str, str], title: str, partner_name: str, room_name: str, weather_label: str, price: str, partner_address: str) -> str:
        palette = {
            "themepark": ("#e9a34d", "#1c5e54", "#fff0cc"),
            "kids": ("#e17b64", "#24695e", "#fff1d4"),
            "nature": ("#6a9b70", "#245a50", "#e9f3df"),
            "sport": ("#4e7d9e", "#1c5360", "#e5f3f5"),
            "nightlife": ("#6e5b9b", "#202b4d", "#f1e7ff"),
            "photo": ("#d49a79", "#284e56", "#ffe9d8"),
            "food": ("#c87b4a", "#5a3f2f", "#fff0dc"),
            "performance": ("#9d5f78", "#4d2744", "#fce5ee"),
            "entertainment": ("#6b8eb8", "#243b5b", "#e8f2ff"),
            "city_walk": ("#7fa9a2", "#21554f", "#e8f3ed"),
            "culture": ("#d19b5d", "#174d46", "#f6e8ce"),
            "tea": ("#86a66d", "#365a48", "#eff3dc"),
        }
        accent, dark, light = palette.get(profile["key"], ("#d19b5d", "#174d46", "#f6e8ce"))
        safe = lambda value: escape(str(value), quote=True)
        art = {
            "themepark": '<circle cx="270" cy="410" r="88" fill="#fff" opacity=".7"/><path d="M205 410 Q270 315 335 410" fill="none" stroke="#fff" stroke-width="12"/><path d="M225 415 v88 M315 415 v88" stroke="#fff" stroke-width="10"/><circle cx="270" cy="365" r="18" fill="#fff"/>',
            "kids": '<rect x="155" y="370" width="240" height="130" rx="22" fill="#fff" opacity=".8"/><circle cx="215" cy="430" r="30" fill="#e9a56e"/><circle cx="335" cy="430" r="30" fill="#7db5a8"/><path d="M240 455 Q275 490 310 455" fill="none" stroke="#24695e" stroke-width="10"/>',
            "nature": '<path d="M120 510 Q235 300 350 510" fill="#fff" opacity=".75"/><path d="M235 515 V350 M235 410 Q170 365 135 410 M235 430 Q300 380 345 420" fill="none" stroke="#245a50" stroke-width="12"/><circle cx="690" cy="350" r="48" fill="#fff" opacity=".7"/>',
            "sport": '<path d="M160 500 L220 330 L300 500" fill="none" stroke="#fff" stroke-width="24" stroke-linecap="round"/><circle cx="225" cy="320" r="28" fill="#f6c06e"/><path d="M430 460 q115 -80 230 0" fill="none" stroke="#fff" stroke-width="20"/>',
            "nightlife": '<circle cx="250" cy="390" r="82" fill="#f4d488" opacity=".9"/><path d="M180 520 Q300 380 430 520" fill="none" stroke="#fff" stroke-width="16"/><path d="M685 260 v270 M745 300 v230 M805 250 v280" stroke="#fff" stroke-width="10"/><circle cx="685" cy="245" r="12" fill="#f4d488"/><circle cx="745" cy="285" r="12" fill="#f4d488"/>',
            "photo": '<rect x="150" y="350" width="270" height="170" rx="20" fill="#fff" opacity=".8"/><circle cx="285" cy="435" r="54" fill="#d49a79"/><circle cx="285" cy="435" r="30" fill="#284e56"/><path d="M480 500 Q625 340 790 500" fill="none" stroke="#fff" stroke-width="14"/>',
            "food": '<ellipse cx="270" cy="500" rx="180" ry="34" fill="#fff" opacity=".8"/><path d="M140 470 Q160 330 270 330 Q380 330 400 470Z" fill="#fff" opacity=".75"/><circle cx="220" cy="405" r="23" fill="#c87b4a"/><circle cx="300" cy="390" r="23" fill="#e5bb69"/>',
            "performance": '<path d="M150 500 Q300 330 450 500" fill="#fff" opacity=".75"/><circle cx="245" cy="410" r="24" fill="#9d5f78"/><circle cx="355" cy="410" r="24" fill="#4d2744"/><path d="M230 450 Q300 500 370 450" fill="none" stroke="#4d2744" stroke-width="14"/>',
            "entertainment": '<rect x="145" y="360" width="280" height="170" rx="24" fill="#fff" opacity=".78"/><circle cx="215" cy="445" r="28" fill="#6b8eb8"/><circle cx="355" cy="445" r="28" fill="#243b5b"/><path d="M245 445 h80" stroke="#243b5b" stroke-width="12"/>',
            "city_walk": '<path d="M90 520 Q260 390 430 520 T790 510" fill="none" stroke="#fff" stroke-width="22"/><path d="M550 500 v-190 M650 500 v-230" stroke="#21554f" stroke-width="18"/><circle cx="550" cy="285" r="23" fill="#f4d488"/>',
            "culture": '<rect x="145" y="420" width="300" height="70" rx="12" fill="#d19b5d"/><path d="M210 390 l80 120 M370 390 l-80 120" stroke="#174d46" stroke-width="13" stroke-linecap="round"/><circle cx="210" cy="370" r="16" fill="#d45c53"/><circle cx="370" cy="370" r="16" fill="#d45c53"/>',
            "tea": '<ellipse cx="285" cy="480" rx="180" ry="36" fill="#fff" opacity=".7"/><path d="M175 440 Q175 330 285 330 Q395 330 395 440Z" fill="#fff" opacity=".85"/><path d="M395 370 Q480 360 460 435 Q445 480 395 450" fill="none" stroke="#365a48" stroke-width="14"/>',
        }.get(profile["key"], "")
        return (
            '<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1440" viewBox="0 0 1080 1440">'
            f'<rect width="1080" height="1440" rx="36" fill="{light}"/><circle cx="900" cy="140" r="230" fill="{accent}" opacity=".25"/>'
            f'<text x="72" y="90" fill="{dark}" font-size="26" font-weight="700" letter-spacing="4" font-family="Arial, Microsoft YaHei, sans-serif">STAYSCAPE · HANGZHOU</text>'
            f'<rect x="60" y="128" width="960" height="560" rx="34" fill="{accent}"/><path d="M60 560 Q240 450 430 560 T760 540 T1020 500 V688 H60Z" fill="{dark}" opacity=".42"/>'
            f'<g>{art}</g><text x="100" y="770" fill="{dark}" font-size="56" font-weight="700" font-family="Microsoft YaHei, sans-serif">{safe(title[:22])}</text>'
            f'<text x="104" y="820" fill="{dark}" font-size="24" font-family="Microsoft YaHei, sans-serif">{safe(weather_label)} · {safe(profile["tag"])} · {safe(partner_name[:20])}</text>'
            f'<rect x="70" y="885" width="940" height="190" rx="24" fill="#fff" opacity=".85"/><text x="110" y="945" fill="{dark}" font-size="25" font-weight="700" font-family="Microsoft YaHei, sans-serif">住进 {safe(room_name)}，把 {safe(profile["label"])} 放进今晚</text>'
            f'<text x="110" y="995" fill="#5b756e" font-size="22" font-family="Microsoft YaHei, sans-serif">{safe(partner_address[:28])}</text><text x="110" y="1035" fill="#5b756e" font-size="22" font-family="Microsoft YaHei, sans-serif">慢慢体验 · 给今天留一段杭州时间</text>'
            f'<rect x="70" y="1110" width="420" height="190" rx="24" fill="{dark}"/><text x="105" y="1170" fill="#c9eadc" font-size="20" font-family="Microsoft YaHei, sans-serif">为今天安排的一段杭州旅居</text><text x="105" y="1250" fill="#fff" font-size="56" font-weight="700" font-family="Arial, sans-serif">¥{safe(price)}</text>'
            f'<rect x="530" y="1110" width="480" height="190" rx="24" fill="#f2dfad"/><text x="570" y="1170" fill="#7b5b2a" font-size="23" font-weight="700" font-family="Microsoft YaHei, sans-serif">{safe(profile["label"])} · {safe(partner_name[:14])}</text><text x="570" y="1220" fill="#6b6250" font-size="21" font-family="Microsoft YaHei, sans-serif">打开 StayScape，看看这段行程</text>'
            f'<text x="72" y="1370" fill="#5b756e" font-size="21" font-family="Microsoft YaHei, sans-serif">#杭州旅行 #StayScape #{safe(profile["key"])}</text></svg>'
        )

    @classmethod
    def _product(cls, payload: dict[str, Any]) -> dict[str, Any]:
        room = payload.get("room_inventory") or {}
        selections = payload.get("requested_selections") or []
        service_ids = [item["resource_id"] for item in selections if item["resource_type"] == "HOTEL_SERVICE"]
        requested_partner_ids = [item["resource_id"] for item in selections if item["resource_type"] == "PARTNER_RESOURCE"]
        variant_index = int(payload.get("variant_index", 0) or 0)
        partner = cls._pick_partner(payload, requested_partner_ids, variant_index)
        partner_ids = [partner["id"]] if partner else []
        quantities = {str(item["resource_id"]): int(item["quantity_per_package"]) for item in selections}
        for item in payload.get("allowed_hotel_services", []):
            if item["id"] in service_ids and str(item["id"]) not in quantities:
                quantities[str(item["id"])] = 1
        if partner and str(partner["id"]) not in quantities:
            quantities[str(partner["id"])] = 1

        crowd = str(payload.get("target_crowd", "FAMILY")).upper()
        theme = str(payload.get("theme", "杭州城市体验"))
        weather = str(payload.get("weather", "RAIN")).upper()
        weather_label = {"RAIN": "雨天", "SUNNY": "晴日", "CLOUDY": "多云"}.get(weather, "杭州")
        profile = cls._profile(payload, partner)
        partner_name = partner.get("resource_name", profile["label"])
        room_name = room.get("room_type", "舒适客房")
        audience = cls.CROWD_LABELS.get(crowd, crowd)
        service_names = "、".join(item.get("service_name", "贴心服务") for item in payload.get("allowed_hotel_services", []) if item["id"] in service_ids) or "酒店服务"
        partner_time = "-".join(item for item in (partner.get("start_time"), partner.get("end_time")) if item) or "场次待确认"
        partner_address = partner.get("address") or "杭州体验场地"
        partner_description = partner.get("description") or f"{partner_name}，让杭州的这一晚有具体去处。"
        capacity = partner.get("remaining_capacity") or 0
        suffix = ["", "·轻松版", "·加深体验", "·周末版", "·慢享版"][variant_index % 5]
        if variant_index == 0 and crowd == "FAMILY" and ("非遗" in theme or "非遗" in partner_name):
            name = "杭州雨天亲子非遗文化宿"
        else:
            name_options = {
                "THEME_PARK": [f"带娃解锁{partner_name}｜{room_name}+{service_names}", f"周末去{partner_name}｜家庭房与{service_names}"],
                "KIDS": [f"孩子放电计划｜{partner_name}+{room_name}", f"雨天带娃不无聊｜{partner_name}与{service_names}"],
                "NATURE": [f"住一晚再去{partner_name}｜{room_name}+{service_names}", f"给全家留一段自然时间｜{partner_name}"],
                "SPORT": [f"朋友周末玩点刺激的｜{partner_name}+{room_name}", f"把运动安排进一晚旅居｜{partner_name}"],
                "NIGHTLIFE": [f"住一晚再看夜景｜{partner_name}+{room_name}", f"夜色里的杭州约会｜{partner_name}与{service_names}"],
                "PHOTO": [f"把杭州拍进周末｜{partner_name}+{room_name}", f"住一晚去旅拍｜{partner_name}与{service_names}"],
                "FOOD": [f"住进一晚江南味道｜{partner_name}+{service_names}", f"先吃好再慢慢逛｜{partner_name}与{room_name}"],
                "PERFORMANCE": [f"看完演出再回酒店｜{partner_name}+{room_name}", f"把今晚留给{partner_name}｜住宿与{service_names}"],
                "ENTERTAINMENT": [f"朋友见面就该这样玩｜{partner_name}+{room_name}", f"雨天也能玩尽兴｜{partner_name}与{service_names}"],
                "CITY_WALK": [f"住一晚再去城市漫游｜{partner_name}+{room_name}", f"给自己一段杭州慢走时间｜{partner_name}"],
                "TEA": [f"把一杯茶放进杭州周末｜{partner_name}+{room_name}", f"住一晚，慢下来喝杯茶｜{partner_name}"],
                "CULTURE": [f"下雨也不改行程｜{partner_name}+{room_name}", f"把杭州手作安排进一晚｜{partner_name}与{service_names}"],
            }
            options = name_options.get(profile["key"].upper(), [f"住一晚去体验{partner_name}｜{room_name}", f"把{partner_name}安排进今晚行程｜{room_name}"])
            name = options[variant_index % len(options)] + suffix
            if profile["key"] == "sport" and partner_description:
                name = f"{name}｜{partner_description}"
        title = f"把杭州安排进周末｜{name}"
        content = (
            f"为{audience}安排的{theme}主题旅居。以{room_name}为休息地，"
            f"把{service_names}和{partner_name}放进同一天的行程里。"
            f"地点在{partner_address}，{partner_description}"
            f"出发前，酒店会和你确认体验时间与到店安排。"
        )
        poster_svg = cls._poster_svg(profile=profile, title=title, partner_name=partner_name, room_name=room_name, weather_label=weather_label, price=payload.get("preferred_price", "599"), partner_address=partner_address)
        social_post = (
            f"这个周末的杭州，也值得住一晚。\n\n"
            f"{partner_description}\n\n"
            f"这次把 {room_name}、{service_names} 和 {partner_name} 排成一张轻松的时间卡。\n"
            f"不用赶很多景点，按 {partner_time} 去 {partner_address}，把{profile['label']}变成旅程里最具体的一段。\n\n"
            f"出发前，酒店会和你确认时间与到店安排。\n\n"
            f"{profile['hashtags']} #杭州酒店 #StayScape"
        )
        short_video = (
            f"0-3秒：杭州城市或酒店窗景；3-8秒：{room_name}与{service_names}；"
            f"8-18秒：拍到{partner_name}的体验画面；18-25秒：字幕展示{partner_time}与{partner_address}；"
            "25-30秒：把这段杭州时光留给周末，邀请旅人查看行程。"
        )
        return {
            "product_name": name,
            "theme": theme,
            "target_crowd": crowd,
            "room_inventory_id": int(room.get("id")),
            "hotel_service_ids": service_ids,
            "partner_resource_ids": partner_ids,
            "resource_quantities": quantities,
            "marketing_title": title,
            "marketing_content": content,
            "creative_angle": f"{profile['label']}的具体城市体验主视觉：{partner_name} + {room_name}",
            "poster_style": f"{profile['key']}-editorial",
            "marketing_assets": [
                {"asset_type": "POSTER", "platform": "StayScape / 小红书封面", "title": title, "content": content, "visual_brief": f"以{profile['label']}（{profile['tag']}）为主视觉，画面包含{partner_name}、{room_name}与体验现场氛围，不使用空泛纯色背景。", "creative_angle": f"{profile['label']}的具体城市体验主视觉", "poster_style": f"{profile['key']}-editorial", "call_to_action": "查看场次 · 提交预约意向", "poster_svg": poster_svg},
                {"asset_type": "SOCIAL_POST", "platform": "小红书 / 朋友圈", "title": f"杭州周末：{profile['label']}值得住一晚", "content": social_post, "visual_brief": f"首图突出{partner_name}具体体验，后续展示房间、城市场景、行程片段和城市氛围。", "call_to_action": "收藏这段杭州行程"},
                {"asset_type": "SHORT_VIDEO_SCRIPT", "platform": "短视频 30 秒", "title": f"30秒讲清{profile['label']}主题宿", "content": short_video, "visual_brief": "镜头必须出现房间、服务、体验现场和时间地点四类具体画面。", "call_to_action": "看看这段行程"},
                {"asset_type": "STORE_CARD", "platform": "OTA / 酒店前台", "title": f"{profile['label']}产品卖点卡", "content": f"杭州周末 · {room_name} · {service_names} · {partner_name}\n场次 {partner_time} · {partner_address}\n适合 {audience} · ¥{payload.get('preferred_price', '599')} / 套 · 余 {capacity} 个名额", "visual_brief": "用房间、服务、体验、地点四块信息替代大段宣传语。", "call_to_action": "查看详情"},
            ],
            "recommendation_reason": f"以{room_name}为休息地，把{service_names}和{partner_name}安排进同一天，适合{audience}慢慢体验{profile['label']}。",
            "risk_message": "如有饮食、儿童陪同或行动安排方面的需求，提交预约意向时告诉我们即可。",
        }

    @classmethod
    def _marketing(cls, payload: dict[str, Any]) -> dict[str, Any]:
        full = cls._product(payload)
        return {
            "marketing_title": full["marketing_title"],
            "marketing_content": full["marketing_content"],
            "creative_angle": full["creative_angle"],
            "poster_style": full["poster_style"],
            "marketing_assets": full["marketing_assets"],
        }

    @staticmethod
    def _visitor(payload: dict[str, Any]) -> dict[str, Any]:
        products = payload.get("products", [])
        target_ids = [item["id"] for item in products if item.get("sale_quantity", 0) > 0]
        allergy = payload.get("allergy_information", "")
        natural_language = str(payload.get("natural_language", "")).strip()
        negative = payload.get("negative_interests", []) or []
        needs_hint = f"我先按你的描述整理：{natural_language}。" if natural_language else ""
        question = str(payload.get("question", "")).strip()
        if question:
            answer = f"{needs_hint}关于“{question}”，我会结合你的同行方式、偏好和想去的地方，帮你看看怎么安排更合适。"
        elif target_ids:
            answer = f"{needs_hint}我为你挑出了 {len(target_ids)} 段杭州玩法，已经优先考虑预算、同行人数和兴趣偏好。"
        else:
            answer = f"{needs_hint}暂时还没有特别合适的方案。你可以换个日期、预算或想去的地方，我继续帮你找。"
        return {
            "answer": answer,
            "safety_notes": "如有过敏、儿童陪同或特殊饮食需求，请在提交预约意向时告诉酒店。",
            "selected_product_ids": target_ids,
            "reasons": {str(item["id"]): f"结合预算、同行方式和玩法偏好挑选；也避开了你不想安排的内容：{'、'.join(negative) or '暂无'}。" for item in products if item["id"] in target_ids},
            "schedule_notes": {str(item["id"]): [{"time": "15:00", "title": "办理入住", "description": "到店后办理入住，稍作休息再出发"}, {"time": "16:00", "title": "前往体验", "description": "酒店会在出行前和你确认具体时间与地点"}] for item in products if item["id"] in target_ids},
            "limited_adjustments": {str(item["id"]): ["可在预约意向中备注希望的场次与同行注意事项", "实时名额变化后以酒店与商户确认结果为准"] for item in products if item["id"] in target_ids},
            "allergy_warning": f"已记录过敏信息：{allergy}；酒店与商户需要在确认前再次核对。" if allergy else "如有过敏或饮食禁忌，请在预约意向中主动说明。",
        }
