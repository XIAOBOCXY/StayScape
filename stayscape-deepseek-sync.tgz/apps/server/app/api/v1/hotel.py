from datetime import date, datetime, timedelta, timezone
from decimal import Decimal

from fastapi import APIRouter, Body, Depends, File, Query, UploadFile
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload

from ...core.exceptions import AppError
from ...config import settings
from ...db import get_db
from ...models import AgentConversation, Hotel, HotelService, Merchant, PartnerResource, ProductProposal, ProductResource, ResourceChangeEvent, RoomInventory, SkillCallLog, TravelProduct, User, VisitorIntent
from ...repositories.product_repository import get_product, list_products
from ...repositories.resource_repository import list_partner_resources, list_rooms, list_services
from ...schemas.dashboard import DashboardResponse
from ...schemas.products import AdjustmentRead, BatchMarketingRefinementRequest, GenerateProductRequest, MarketingRegenerationRequest, ProductDetailResponse, ProductDraftInterpretRequest, ProductDraftInterpretResponse, ProductGenerateResponse, ProductListResponse, ProductRead, ProductStatusRequest, ProductUpdateRequest, ResourceChangeResponse
from ...schemas.ai_operations import AssistantConversationCreate, AssistantMessageCreate, AgentConversationRead, AssistantTaskResponse, ProductProposalRead, ProposalConfirmRequest
from ...schemas.visitor import VisitorIntentStatusUpdate
from ...schemas.resources import MediaImportRequest, MediaSearchRequest, MerchantRead, PackageToggleRequest, PartnerResourceRead, ResourceMediaUpdate, RoomCreate, RoomRead, RoomUpdate, ServiceCreate, ServiceRead, ServiceUpdate
from ...services.product_service import ProductService
from ...services.product_proposal_service import ProductProposalService
from ...services.product_draft_parser import interpret_product_draft
from ...services.operations_insight_service import OperationsInsightService
from ...services.knowledge_service import KnowledgeService
from ...services.weather_service import WeatherService
from ...services.inventory_service import release_intent_inventory, reconcile_published_capacity, sweep_expired_intents
from ...services.serializers import partner_resource_to_dict, product_to_dict
from ...services.media_library_service import MAX_MEDIA_BYTES, MediaLibraryService
from ...agent.openclaw import OpenClawAgent
from ...agent.context import RequestContext
from ..deps import get_hotel_user, resolve_hotel_id
from ..websocket_manager import manager

router = APIRouter(prefix="/hotel", tags=["hotel"])


def hotel_id_for(db: Session, user: User) -> int:
    return resolve_hotel_id(db, user)


def proposal_to_dict(db: Session, proposal: ProductProposal) -> dict:
    """Serialize only auditable task state, never an Agent reasoning trace."""
    product = get_product(db, proposal.product_id)
    return {
        "id": proposal.id,
        "hotel_id": proposal.hotel_id,
        "conversation_id": proposal.conversation_id,
        "product_id": proposal.product_id,
        "source_channel": proposal.source_channel,
        "status": proposal.status,
        "trace_ids": proposal.trace_ids or [],
        "insight_snapshot": proposal.insight_snapshot,
        "weather_snapshot": proposal.weather_snapshot,
        "knowledge_snapshot": proposal.knowledge_snapshot or [],
        "execution_steps": proposal.execution_steps or [],
        "confirmation_action": proposal.confirmation_action,
        "confirmed_by": proposal.confirmed_by,
        "confirmed_at": proposal.confirmed_at,
        "created_at": proposal.created_at,
        "updated_at": proposal.updated_at,
        "product": product_to_dict(product) if product else None,
    }


def _hotel_conversation_or_404(db: Session, hotel_id: int, conversation_id: int) -> AgentConversation:
    conversation = db.scalar(select(AgentConversation).where(AgentConversation.id == conversation_id, AgentConversation.hotel_id == hotel_id))
    if not conversation:
        raise AppError("NOT_FOUND", "AI 运营任务不存在", status_code=404)
    return conversation


@router.post("/ai/conversations", response_model=AgentConversationRead)
def create_ai_conversation(request: AssistantConversationCreate, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    service = ProductProposalService(db, hotel_id, RequestContext(source_channel="WEB_HOTEL", actor_role="HOTEL_OPERATOR", hotel_id=hotel_id, user_id=user.id))
    conversation = service.conversation(title=request.title)
    db.commit()
    db.refresh(conversation)
    return conversation


@router.get("/ai/conversations", response_model=list[AgentConversationRead])
def ai_conversations(db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    return list(db.scalars(select(AgentConversation).where(AgentConversation.hotel_id == hotel_id).order_by(AgentConversation.updated_at.desc()).limit(30)).all())


@router.get("/ai/conversations/{conversation_id}", response_model=AgentConversationRead)
def ai_conversation(conversation_id: int, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    return _hotel_conversation_or_404(db, hotel_id_for(db, user), conversation_id)


@router.post("/ai/conversations/{conversation_id}/messages", response_model=AssistantTaskResponse)
def ai_conversation_message(conversation_id: int, request: AssistantMessageCreate, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    conversation = _hotel_conversation_or_404(db, hotel_id, conversation_id)
    context = RequestContext(source_channel="WEB_HOTEL", actor_role="HOTEL_OPERATOR", hotel_id=hotel_id, user_id=user.id, conversation_id=str(conversation.id))
    proposals = ProductProposalService(db, hotel_id, context).create_from_language(request.natural_language, conversation=conversation)
    db.commit()
    db.refresh(conversation)
    return {"conversation": conversation, "proposals": [proposal_to_dict(db, item) for item in proposals], "message": "已生成待确认候选；确认后才会进入草稿或对游客发布。"}


@router.get("/ai/proposals", response_model=list[ProductProposalRead])
def ai_proposals(status: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    context = RequestContext(source_channel="WEB_HOTEL", actor_role="HOTEL_OPERATOR", hotel_id=hotel_id, user_id=user.id)
    return [proposal_to_dict(db, item) for item in ProductProposalService(db, hotel_id, context).list_proposals(status=status)]


@router.post("/ai/proposals/{proposal_id}/confirm", response_model=ProductProposalRead)
def confirm_ai_proposal(proposal_id: int, request: ProposalConfirmRequest, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    service = ProductProposalService(db, hotel_id, RequestContext(source_channel="WEB_HOTEL", actor_role="HOTEL_OPERATOR", hotel_id=hotel_id, user_id=user.id))
    proposal = service.confirm(proposal_id, action=request.action, confirmed_by=f"web-user:{user.id}")
    db.commit()
    return proposal_to_dict(db, proposal)


@router.get("/ai/overview")
def ai_overview(target_date: date | None = None, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    """One compact, review-friendly view of facts used by hotel AI tasks."""
    hotel_id = hotel_id_for(db, user)
    selected_date = target_date or date.today()
    proposals = list(db.scalars(select(ProductProposal).where(ProductProposal.hotel_id == hotel_id, ProductProposal.status == "PENDING_CONFIRMATION")).all())
    return {
        "operations_insights": OperationsInsightService(db, hotel_id).snapshot(target_date=selected_date),
        "weather": WeatherService(db).get_forecast("杭州", selected_date),
        "knowledge": KnowledgeService(db).search(limit=12),
        "pending_confirmation_count": len(proposals),
        "disclosure": "执行面板只展示可审计步骤与数据来源，不展示模型内部推理。",
    }


@router.post("/media/upload")
async def upload_media(file: UploadFile = File(...), user: User = Depends(get_hotel_user)):
    _ = user
    content = await file.read(MAX_MEDIA_BYTES + 1)
    if len(content) > MAX_MEDIA_BYTES:
        raise AppError("MEDIA_CONTENT_INVALID", "图片不能超过 12MB。", field="file")
    return MediaLibraryService().store_upload(content, file.content_type)


@router.post("/media/search")
def search_media(request: MediaSearchRequest, user: User = Depends(get_hotel_user)):
    _ = user
    return {"items": MediaLibraryService().search_public(request.query, request.limit)}


@router.post("/media/import")
def import_media(request: MediaImportRequest, user: User = Depends(get_hotel_user)):
    _ = user
    return MediaLibraryService().import_remote(request.url, source=request.source, attribution=request.attribution)


def room_status(count: int, requested: str | None = None) -> str:
    if requested == "DISABLED":
        return "DISABLED"
    if count <= 0:
        return "SOLD_OUT"
    return "LOW_STOCK" if count <= 2 else "AVAILABLE"


def service_status(quantity: int, requested: str | None = None) -> str:
    if requested in {"UNAVAILABLE", "SUSPENDED", "EXPIRED"}:
        return requested
    return "SOLD_OUT" if quantity <= 0 else "AVAILABLE"


def room_snapshot(room: RoomInventory) -> dict:
    return {
        "id": room.id,
        "room_type": room.room_type,
        "available_date": room.available_date.isoformat(),
        "available_count": room.available_count,
        "status": room.status,
        "minimum_price": str(room.minimum_price),
        "normal_price": str(room.normal_price),
        "accounting_cost": str(room.accounting_cost),
        "max_guests": room.max_guests,
        "features": room.features,
        "suitable_crowds": room.suitable_crowds,
        "tags": room.tags,
    }


def service_snapshot(service: HotelService) -> dict:
    return {"id": service.id, "available_quantity": service.available_quantity, "status": service.status, "unit_cost": str(service.unit_cost), "reference_price": str(service.reference_price)}


@router.get("/dashboard", response_model=DashboardResponse)
def dashboard(db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    sweep_expired_intents(db, hotel_id)
    db.commit()
    hotel = db.get(Hotel, hotel_id)
    today = date.today()
    target = today + timedelta(days=1)
    rooms = list_rooms(db, hotel_id)
    resources = list_partner_resources(db, hotel_id)
    products = list_products(db, hotel_id)
    hotel_intents = list(
        db.scalars(
            select(VisitorIntent)
            .join(TravelProduct)
            .options(selectinload(VisitorIntent.product))
            .where(TravelProduct.hotel_id == hotel_id)
        ).all()
    )
    intents = len(hotel_intents)
    active_statuses = {"ON_SALE", "LOW_STOCK"}
    active_products = [item for item in products if item.status in active_statuses]
    confirmed = [item for item in hotel_intents if item.reservation_status == "CONFIRMED" and item.product]
    held = [item for item in hotel_intents if item.reservation_status == "HELD" and item.product]
    zero = Decimal("0")
    confirmed_revenue = sum((item.product.suggested_price for item in confirmed if item.product), zero)
    confirmed_gross_profit = sum((item.product.gross_profit for item in confirmed if item.product), zero)
    held_revenue = sum((item.product.suggested_price for item in held if item.product), zero)
    available_package_count = sum(max(0, item.sale_quantity) for item in active_products)
    listed_value = sum((item.suggested_price * max(0, item.sale_quantity) for item in active_products), zero)

    # Keep the revenue series factual: confirmed bookings are income, while
    # held reservations remain visible separately and never inflate sales.
    timeline_dates = {today - timedelta(days=offset) for offset in range(6, -1, -1)}
    timeline_dates.update(item.target_date for item in active_products if item.target_date >= today)
    timeline_dates.update(
        item.confirmed_at.date()
        for item in confirmed
        if item.confirmed_at is not None
    )
    timeline: dict[date, dict] = {
        value: {
            "date": value.isoformat(),
            "confirmed_orders": 0,
            "confirmed_revenue": zero,
            "confirmed_gross_profit": zero,
            "on_sale_products": 0,
            "available_packages": 0,
            "listed_value": zero,
        }
        for value in sorted(timeline_dates)
    }
    for product in active_products:
        point = timeline.setdefault(product.target_date, {
            "date": product.target_date.isoformat(), "confirmed_orders": 0,
            "confirmed_revenue": zero, "confirmed_gross_profit": zero,
            "on_sale_products": 0, "available_packages": 0, "listed_value": zero,
        })
        point["on_sale_products"] += 1
        point["available_packages"] += max(0, product.sale_quantity)
        point["listed_value"] += product.suggested_price * max(0, product.sale_quantity)
    for intent in confirmed:
        if not intent.product or not intent.confirmed_at:
            continue
        value = intent.confirmed_at.date()
        point = timeline.setdefault(value, {
            "date": value.isoformat(), "confirmed_orders": 0,
            "confirmed_revenue": zero, "confirmed_gross_profit": zero,
            "on_sale_products": 0, "available_packages": 0, "listed_value": zero,
        })
        point["confirmed_orders"] += 1
        point["confirmed_revenue"] += intent.product.suggested_price
        point["confirmed_gross_profit"] += intent.product.gross_profit
    changes = list(db.scalars(select(ResourceChangeEvent).where(ResourceChangeEvent.hotel_id == hotel_id).order_by(ResourceChangeEvent.created_at.desc()).limit(6)).all())
    return {
        "hotel_id": hotel_id,
        "hotel_name": hotel.name if hotel else "StayScape",
        "target_date": target.isoformat(),
        "room_count": len(rooms),
        "expiring_room_count": sum(1 for item in rooms if item.available_date == target),
        "available_room_units": sum(max(0, item.available_count) for item in rooms if item.available_date == target),
        "partner_resource_count": len(resources),
        "package_enabled_resource_count": sum(1 for item in resources if item.package_enabled and item.status == "AVAILABLE"),
        "product_count": len(products),
        "on_sale_product_count": len(active_products),
        "low_stock_product_count": sum(1 for item in products if item.status == "LOW_STOCK"),
        "visitor_intent_count": int(intents),
        "gross_profit_on_sale": sum((item.gross_profit * item.sale_quantity for item in active_products), zero),
        "confirmed_order_count": len(confirmed),
        "confirmed_revenue": confirmed_revenue,
        "confirmed_gross_profit": confirmed_gross_profit,
        "held_order_count": len(held),
        "held_revenue": held_revenue,
        "available_package_count": available_package_count,
        "listed_value": listed_value,
        "sales_timeline": [timeline[value] for value in sorted(timeline)],
        "recent_changes": [{"id": item.id, "event_type": item.event_type, "resource_type": item.resource_type, "resource_id": item.resource_id, "reason": item.reason, "processed": item.processed, "created_at": item.created_at} for item in changes],
    }


@router.get("/rooms", response_model=list[RoomRead])
def rooms(db: Session = Depends(get_db), user: User = Depends(get_hotel_user), target_date: date | None = Query(default=None)):
    hotel_id = hotel_id_for(db, user)
    items = list_rooms(db, hotel_id)
    return [item for item in items if target_date is None or item.available_date == target_date]


@router.post("/rooms", response_model=RoomRead)
def create_room(request: RoomCreate, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    if request.minimum_price > request.normal_price:
        raise AppError("VALIDATION_ERROR", "最低售价不能高于正常售价", field="minimum_price")
    hotel_id = hotel_id_for(db, user)
    item = RoomInventory(hotel_id=hotel_id, **request.model_dump(), status=room_status(request.available_count))
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@router.patch("/rooms/{room_id}", response_model=RoomRead)
async def update_room(room_id: int, request: RoomUpdate, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    room = db.scalar(select(RoomInventory).where(RoomInventory.id == room_id, RoomInventory.hotel_id == hotel_id).with_for_update())
    if not room:
        raise AppError("NOT_FOUND", "客房库存不存在", status_code=404)
    old = room_snapshot(room)
    data = request.model_dump(exclude_unset=True, exclude={"reason"})
    for key, value in data.items():
        setattr(room, key, value)
    if room.minimum_price > room.normal_price:
        raise AppError("VALIDATION_ERROR", "最低售价不能高于正常售价", field="minimum_price")
    if room.available_count < 0 or room.accounting_cost <= 0:
        raise AppError("VALIDATION_ERROR", "库存和核算成本必须合法")
    room.status = room_status(room.available_count, request.status or room.status)
    event = ResourceChangeEvent(event_type="ROOM_INVENTORY_CHANGED", resource_type="ROOM", resource_id=room.id, hotel_id=hotel_id, old_value=old, new_value=room_snapshot(room), reason=request.reason, operator_role=user.role, operator_id=user.id)
    db.add(event)
    db.flush()
    affected = ProductService(db, hotel_id).recalculate_for_event(event)
    db.commit()
    await manager.broadcast(hotel_id, {"type": "RESOURCE_CHANGE", "title": "临期客房发生变化", "message": request.reason, "affectedProducts": affected})
    db.refresh(room)
    return room


@router.get("/services", response_model=list[ServiceRead])
def services(db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    return list_services(db, hotel_id_for(db, user))


@router.post("/services", response_model=ServiceRead)
def create_service(request: ServiceCreate, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    if request.start_time and request.end_time and request.start_time >= request.end_time:
        raise AppError("TIME_INVALID", "服务开始时间必须早于结束时间")
    hotel_id = hotel_id_for(db, user)
    item = HotelService(hotel_id=hotel_id, **request.model_dump(), status=service_status(request.available_quantity))
    db.add(item)
    db.commit()
    db.refresh(item)
    return item


@router.patch("/services/{service_id}", response_model=ServiceRead)
async def update_service(service_id: int, request: ServiceUpdate, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    service = db.scalar(select(HotelService).where(HotelService.id == service_id, HotelService.hotel_id == hotel_id).with_for_update())
    if not service:
        raise AppError("NOT_FOUND", "酒店服务不存在", status_code=404)
    old = service_snapshot(service)
    data = request.model_dump(exclude_unset=True, exclude={"reason"})
    for key, value in data.items():
        setattr(service, key, value)
    if service.available_quantity < 0:
        raise AppError("VALIDATION_ERROR", "服务名额不能为负数", field="available_quantity")
    if service.start_time and service.end_time and service.start_time >= service.end_time:
        raise AppError("TIME_INVALID", "服务开始时间必须早于结束时间")
    service.status = service_status(service.available_quantity, service.status)
    event_type = "HOTEL_SERVICE_STATUS_CHANGED" if old["status"] != service.status else "HOTEL_SERVICE_QUANTITY_CHANGED"
    event = ResourceChangeEvent(event_type=event_type, resource_type="HOTEL_SERVICE", resource_id=service.id, hotel_id=hotel_id, old_value=old, new_value=service_snapshot(service), reason=request.reason, operator_role=user.role, operator_id=user.id)
    db.add(event)
    db.flush()
    affected = ProductService(db, hotel_id).recalculate_for_event(event)
    db.commit()
    await manager.broadcast(hotel_id, {"type": "RESOURCE_CHANGE", "title": "酒店服务发生变化", "message": request.reason, "affectedProducts": affected})
    db.refresh(service)
    return service


@router.get("/merchants", response_model=list[MerchantRead])
def merchants(db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    return list(db.scalars(select(Merchant).where(Merchant.hotel_id == hotel_id_for(db, user)).order_by(Merchant.id)).all())


@router.get("/resources", response_model=list[PartnerResourceRead])
def resources(db: Session = Depends(get_db), user: User = Depends(get_hotel_user), only_package_enabled: bool | None = None):
    hotel_id = hotel_id_for(db, user)
    items = list_partner_resources(db, hotel_id)
    result = []
    for item in items:
        if only_package_enabled is not None and item.package_enabled != only_package_enabled:
            continue
        count = db.scalar(select(func.count(ProductResource.id)).where(ProductResource.resource_type == "PARTNER_RESOURCE", ProductResource.resource_id == item.id)) or 0
        result.append(partner_resource_to_dict(item, int(count)))
    return result


@router.patch("/resources/{resource_id}/package", response_model=PartnerResourceRead)
async def toggle_package(
    resource_id: int,
    request: PackageToggleRequest | None = Body(default=None),
    package_enabled: bool | None = Query(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_hotel_user),
):
    enabled = request.package_enabled if request is not None else package_enabled
    if enabled is None:
        raise AppError("VALIDATION_ERROR", "请提供组包许可状态", field="package_enabled")
    hotel_id = hotel_id_for(db, user)
    resource = db.scalar(select(PartnerResource).join(Merchant).options(selectinload(PartnerResource.merchant)).where(PartnerResource.id == resource_id, Merchant.hotel_id == hotel_id).with_for_update())
    if not resource:
        raise AppError("NOT_FOUND", "合作资源不存在", status_code=404)
    old = {"package_enabled": resource.package_enabled, "status": resource.status}
    resource.package_enabled = enabled
    event = ResourceChangeEvent(event_type="PARTNER_RESOURCE_STATUS_CHANGED", resource_type="PARTNER_RESOURCE", resource_id=resource.id, hotel_id=hotel_id, old_value=old, new_value={"package_enabled": resource.package_enabled, "status": resource.status}, reason="酒店调整组包许可", operator_role=user.role, operator_id=user.id)
    db.add(event)
    db.flush()
    affected = ProductService(db, hotel_id).recalculate_for_event(event)
    db.commit()
    await manager.broadcast(hotel_id, {"type": "RESOURCE_CHANGE", "title": "合作资源组包许可发生变化", "message": "酒店调整了资源组包许可", "affectedProducts": affected})
    db.refresh(resource)
    count = db.scalar(select(func.count(ProductResource.id)).where(ProductResource.resource_type == "PARTNER_RESOURCE", ProductResource.resource_id == resource.id)) or 0
    return partner_resource_to_dict(resource, int(count))


@router.patch("/resources/{resource_id}/media", response_model=PartnerResourceRead)
async def update_resource_media(resource_id: int, request: ResourceMediaUpdate, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    resource = db.scalar(select(PartnerResource).join(Merchant).options(selectinload(PartnerResource.merchant)).where(PartnerResource.id == resource_id, Merchant.hotel_id == hotel_id).with_for_update())
    if not resource:
        raise AppError("NOT_FOUND", "合作资源不存在", status_code=404)
    resource.image_url = request.image_url
    resource.image_source = request.image_source
    resource.image_attribution = request.image_attribution
    event = ResourceChangeEvent(event_type="PARTNER_RESOURCE_MEDIA_CHANGED", resource_type="PARTNER_RESOURCE", resource_id=resource.id, hotel_id=hotel_id, old_value={}, new_value={"image_url": bool(resource.image_url)}, reason="酒店更新合作资源图片", operator_role=user.role, operator_id=user.id, processed=True)
    db.add(event)
    db.commit()
    await manager.broadcast(hotel_id, {"type": "RESOURCE_CHANGE", "title": "合作资源图片已更新", "message": resource.resource_name, "affectedProducts": []})
    db.refresh(resource)
    count = db.scalar(select(func.count(ProductResource.id)).where(ProductResource.resource_type == "PARTNER_RESOURCE", ProductResource.resource_id == resource.id)) or 0
    return partner_resource_to_dict(resource, int(count))


@router.get("/products", response_model=ProductListResponse)
def products(db: Session = Depends(get_db), user: User = Depends(get_hotel_user), status: str | None = None):
    items = list_products(db, hotel_id_for(db, user))
    if status:
        items = [item for item in items if item.status == status]
    else:
        # A generated candidate is not a hotel product yet. It becomes visible
        # in this list only after the operator confirms draft or publish.
        items = [item for item in items if item.status != "PENDING_CONFIRMATION"]
    return {"items": [product_to_dict(item) for item in items], "total": len(items)}


@router.post("/products/generate", response_model=ProductGenerateResponse)
def generate_product(request: GenerateProductRequest, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    generated = ProductService(db, hotel_id_for(db, user)).generate_many(request)
    db.commit()
    products = [item[0] for item in generated]
    trace_ids = [item[2] for item in generated]
    log = db.scalar(select(SkillCallLog).where(SkillCallLog.trace_id == trace_ids[0])) if trace_ids else None
    return {
        "product": product_to_dict(products[0]),
        "products": [product_to_dict(item) for item in products],
        "trace_id": generated[0][2],
        "trace_ids": trace_ids,
        "validation": generated[0][1],
        "fallback_used": any(item[3] for item in generated),
        "provider": log.provider if log else "MOCK",
        "transport": log.transport if log else "mock",
        "agent_id": log.agent_id if log else "",
        "skill_name": log.skill_name if log else "stayscape-product-generator",
        "skill_version": log.skill_version if log else "",
    }


@router.post("/products/interpret", response_model=ProductDraftInterpretResponse)
def interpret_product_request(request: ProductDraftInterpretRequest, user: User = Depends(get_hotel_user)):
    # Authentication keeps the operator's free-text brief within their own
    # workspace.  This parser has no model call and never writes inventory.
    _ = user
    return interpret_product_draft(request.natural_language)


@router.get("/products/{product_id}", response_model=ProductDetailResponse)
def product_detail(product_id: int, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    product = get_product(db, product_id)
    if not product or product.hotel_id != hotel_id_for(db, user):
        raise AppError("NOT_FOUND", "产品不存在", status_code=404)
    return product_to_dict(product, include_adjustments=True)


@router.patch("/products/{product_id}", response_model=ProductRead)
def update_product(product_id: int, request: ProductUpdateRequest, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    product = get_product(db, product_id)
    if not product or product.hotel_id != hotel_id or product.status == "DELETED":
        raise AppError("NOT_FOUND", "产品不存在", status_code=404)

    target_date = request.target_date or product.target_date
    room_id = request.room_inventory_id or product.room_inventory_id
    room = db.scalar(select(RoomInventory).where(RoomInventory.id == room_id, RoomInventory.hotel_id == hotel_id))
    if not room:
        raise AppError("NOT_FOUND", "产品关联客房不存在", status_code=404)
    if room.available_date != target_date:
        same_type = db.scalar(select(RoomInventory).where(RoomInventory.hotel_id == hotel_id, RoomInventory.room_type == room.room_type, RoomInventory.available_date == target_date).order_by(RoomInventory.available_count.desc()))
        if same_type:
            room = same_type
            room_id = same_type.id
        else:
            raise AppError("DATE_NOT_MATCHED", "没有找到目标日期可用的同房型库存，请先维护客房日期", field="target_date", retryable=True)

    if target_date != product.target_date or room_id != product.room_inventory_id:
        for row in product.resources:
            if row.resource_type == "HOTEL_SERVICE":
                source = db.get(HotelService, row.resource_id)
            elif row.resource_type == "PARTNER_RESOURCE":
                source = db.get(PartnerResource, row.resource_id)
            else:
                source = room
            if source is not None and source.available_date != target_date:
                raise AppError("DATE_NOT_MATCHED", f"资源{row.resource_name}未维护目标日期，请先调整资源日期", field="target_date", retryable=True)

    changed = request.model_dump(exclude_unset=True, exclude={"regenerate_marketing", "target_date", "room_inventory_id"})
    if request.target_date is not None:
        changed["target_date"] = target_date
    if request.room_inventory_id is not None or target_date != product.target_date:
        changed["room_inventory_id"] = room_id
    if target_date != product.target_date:
        forecast = WeatherService(db).get_forecast("杭州", target_date)
        if forecast.get("usable"):
            changed["weather"] = str(forecast.get("scenario") or product.weather)
        else:
            note = "天气信息需确认，请以出发前最新预报为准。"
            changed["risk_message"] = f"{product.risk_message} {note}".strip()
    weather_or_context_changed = any(key in changed for key in ("target_date", "room_inventory_id", "weather", "target_crowd"))
    for key, value in changed.items():
        setattr(product, key, value)
    db.flush()

    service = ProductService(db, hotel_id)
    if weather_or_context_changed:
        service.recalculate_product(product)
        reconcile_published_capacity(db, hotel_id, priority_product_id=product.id if product.status in {"ON_SALE", "LOW_STOCK"} else None)
    if request.regenerate_marketing or any(key in changed for key in ("theme", "weather", "target_crowd")):
        service.regenerate_marketing(product)
    db.commit()
    return product_to_dict(product)


@router.post("/products/{product_id}/marketing-assets", response_model=ProductRead)
def regenerate_marketing_assets(
    product_id: int,
    request: MarketingRegenerationRequest | None = Body(default=None),
    db: Session = Depends(get_db),
    user: User = Depends(get_hotel_user),
):
    hotel_id = hotel_id_for(db, user)
    product = get_product(db, product_id)
    if not product or product.hotel_id != hotel_id or product.status == "DELETED":
        raise AppError("NOT_FOUND", "产品不存在", status_code=404)
    options = request or MarketingRegenerationRequest()
    ProductService(db, hotel_id).regenerate_marketing(product, style=options.style, generate_image=options.generate_image)
    db.commit()
    return product_to_dict(product)


@router.post("/products/refine-marketing", response_model=list[ProductRead])
def refine_generated_product_marketing(
    request: BatchMarketingRefinementRequest,
    db: Session = Depends(get_db),
    user: User = Depends(get_hotel_user),
):
    """Apply one operator instruction to several generated product candidates.

    This is deliberately constrained to the creative surface.  The hotel can
    use language such as “改成更适合带娃的轻松种草口吻”，while FastAPI keeps
    all real allocations and prices untouched and therefore still valid.
    """

    hotel_id = hotel_id_for(db, user)
    ordered_ids = list(dict.fromkeys(request.product_ids))
    if len(ordered_ids) != len(request.product_ids):
        raise AppError("VALIDATION_ERROR", "请不要重复选择同一套候选产品", field="product_ids")
    products = [get_product(db, product_id) for product_id in ordered_ids]
    if any(not product or product.hotel_id != hotel_id or product.status == "DELETED" for product in products):
        raise AppError("NOT_FOUND", "存在不可编辑的产品候选", status_code=404)

    service = ProductService(db, hotel_id)
    for product in products:
        service.regenerate_marketing(
            product,
            creative_direction=request.natural_language,
            style=request.style,
            generate_image=request.generate_image,
        )
    db.commit()
    return [product_to_dict(product) for product in products]


@router.delete("/products/{product_id}")
def delete_product(product_id: int, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    product = get_product(db, product_id)
    if not product or product.hotel_id != hotel_id or product.status == "DELETED":
        raise AppError("NOT_FOUND", "产品不存在", status_code=404)
    intent_count = db.scalar(select(func.count(VisitorIntent.id)).where(VisitorIntent.product_id == product.id)) or 0
    if intent_count:
        product.status = "DELETED"
        db.commit()
        return {"deleted": True, "archived": True, "message": "产品已有预约意向，已安全归档并从产品池移除"}
    db.delete(product)
    db.commit()
    return {"deleted": True, "archived": False, "message": "产品已删除"}


@router.patch("/products/{product_id}/status", response_model=ProductRead)
def product_status(product_id: int, request: ProductStatusRequest, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    product = get_product(db, product_id)
    if not product or product.hotel_id != hotel_id_for(db, user):
        raise AppError("NOT_FOUND", "产品不存在", status_code=404)
    if product.status == "PENDING_CONFIRMATION":
        raise AppError("PROPOSAL_CONFIRMATION_REQUIRED", "请先在 AI 运营任务中确认该候选，再调整产品状态。", status_code=409)
    if request.status == "ON_SALE":
        ProductService(db, hotel_id_for(db, user)).ensure_publish_capacity(product)
        if product.sale_quantity <= 0:
            raise AppError("CAPACITY_INSUFFICIENT", "库存为0的产品不能发布", field="status")
        product.status = "LOW_STOCK" if product.sale_quantity <= 2 else "ON_SALE"
    else:
        product.status = request.status
    db.commit()
    return product_to_dict(product)


@router.get("/products/{product_id}/adjustments", response_model=list[AdjustmentRead])
def product_adjustments(product_id: int, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    product = get_product(db, product_id)
    if not product or product.hotel_id != hotel_id_for(db, user):
        raise AppError("NOT_FOUND", "产品不存在", status_code=404)
    return product.adjustments


@router.get("/changes")
def changes(db: Session = Depends(get_db), user: User = Depends(get_hotel_user), limit: int = Query(default=50, ge=1, le=200)):
    hotel_id = hotel_id_for(db, user)
    resource_ids = [item.id for item in list_partner_resources(db, hotel_id)]
    items = list(db.scalars(select(ResourceChangeEvent).where(ResourceChangeEvent.hotel_id == hotel_id).order_by(ResourceChangeEvent.created_at.desc()).limit(limit)).all())
    return [{"id": item.id, "event_type": item.event_type, "resource_type": item.resource_type, "resource_id": item.resource_id, "old_value": item.old_value, "new_value": item.new_value, "reason": item.reason, "processed": item.processed, "processing_result": item.processing_result, "created_at": item.created_at} for item in items]


@router.get("/intents")
def intents(db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    sweep_expired_intents(db, hotel_id)
    db.commit()
    items = list(
        db.scalars(
            select(VisitorIntent)
            .join(TravelProduct)
            .options(selectinload(VisitorIntent.product))
            .where(TravelProduct.hotel_id == hotel_id)
            .order_by(VisitorIntent.created_at.desc())
        ).all()
    )
    return [
        {
            "id": item.id,
            "product_id": item.product_id,
            "product_name": item.product.product_name if item.product else "已归档产品",
            "product_code": item.product.product_code if item.product else None,
            "target_date": item.product.target_date if item.product else None,
            "product_status": item.product.status if item.product else None,
            "remaining_quantity": item.product.sale_quantity if item.product else 0,
            "submitted_price": (item.recommendation_result or {}).get("submitted_price") if item.recommendation_result else None,
            "adult_count": item.adult_count,
            "child_count": item.child_count,
            "child_ages": item.child_ages,
            "natural_language": item.natural_language,
            "budget": item.budget,
            "interests": item.interests,
            "negative_interests": item.negative_interests,
            "activity_level": item.activity_level,
            "dietary_restrictions": item.dietary_restrictions,
            "allergy_information": item.allergy_information,
            "arrival_time": item.arrival_time,
            "preferred_experience_time": item.preferred_experience_time,
            "other_requirements": item.other_requirements,
            "recommendation_result": item.recommendation_result,
            "intent_status": item.intent_status,
            "reservation_status": item.reservation_status,
            "reserved_until": item.reserved_until,
            "released_at": item.released_at,
            "confirmed_at": item.confirmed_at,
            "contact_name": item.contact_name,
            "contact_phone": item.contact_phone,
            "created_at": item.created_at,
        }
        for item in items
    ]


@router.patch("/intents/{intent_id}")
async def update_intent_status(intent_id: int, request: VisitorIntentStatusUpdate, db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    hotel_id = hotel_id_for(db, user)
    sweep_expired_intents(db, hotel_id)
    intent = db.scalar(
        select(VisitorIntent)
        .join(TravelProduct)
        .options(selectinload(VisitorIntent.product))
        .where(VisitorIntent.id == intent_id, TravelProduct.hotel_id == hotel_id)
        .with_for_update()
    )
    if not intent:
        raise AppError("NOT_FOUND", "预约意向不存在", status_code=404)
    if request.status == "CONFIRMED":
        if intent.reservation_status not in {"HELD", "CONFIRMED"}:
            raise AppError("INTENT_NOT_ACTIVE", "该预约意向已释放或过期，不能确认")
        intent.reservation_status = "CONFIRMED"
        intent.intent_status = "CONFIRMED"
        intent.confirmed_at = datetime.now(timezone.utc)
        message = "预约意向已确认，底层资源继续保持占用"
    else:
        if intent.reservation_status in {"HELD", "CONFIRMED"}:
            release_intent_inventory(db, intent)
            if intent.product:
                reconcile_published_capacity(db, intent.product.hotel_id)
        intent.reservation_status = "RELEASED"
        intent.intent_status = "CANCELLED"
        message = "预约意向已取消，底层房量、服务和合作名额已释放"
    db.commit()
    await manager.broadcast(hotel_id, {"type": "VISITOR_INTENT_UPDATED", "title": "预约意向状态更新", "message": message, "affectedProducts": [{"product_id": intent.product_id, "new_quantity": intent.product.sale_quantity if intent.product else None}]})
    return {"id": intent.id, "intent_status": intent.intent_status, "reservation_status": intent.reservation_status, "message": message}


@router.get("/skill-logs")
def skill_logs(db: Session = Depends(get_db), user: User = Depends(get_hotel_user), limit: int = Query(default=50, ge=1, le=200)):
    hotel_id = hotel_id_for(db, user)
    items = list(db.scalars(select(SkillCallLog).where(SkillCallLog.hotel_id == hotel_id).order_by(SkillCallLog.created_at.desc()).limit(limit)).all())
    return items


@router.get("/agent-diagnostics")
def agent_diagnostics(db: Session = Depends(get_db), user: User = Depends(get_hotel_user)):
    """Expose safe Agent wiring details to hotel operators, never credentials."""
    is_remote = settings.agent_provider.lower() == "openclaw"
    configured = is_remote and bool(settings.openclaw_base_url and settings.openclaw_gateway_token and settings.openclaw_agent_id)
    gateway = {
        "configured": configured,
        "reachable": False,
        "status_code": None,
        "error": "OpenClaw Gateway not configured" if is_remote else "Demo mode uses Mock Agent",
    }
    if configured:
        agent = OpenClawAgent(settings.openclaw_base_url, settings.openclaw_gateway_token, settings.openclaw_agent_target, settings.agent_timeout_seconds, transport=settings.openclaw_transport, responses_path=settings.openclaw_responses_path, agent_id=settings.openclaw_agent_id, skill_version=settings.openclaw_skill_version, primary_model=settings.openclaw_primary_model)
        gateway = agent.diagnostics()
    provider = "OPENCLAW" if is_remote else "MOCK"
    skill_status = "READY" if is_remote and settings.openclaw_live_ready else ("NOT_READY" if is_remote else "DEMO")
    return {
        "provider": provider,
        "mode": settings.mode,
        "transport": settings.openclaw_transport if is_remote else "mock",
        "gateway": gateway,
        "agent_id": settings.openclaw_agent_id if is_remote else "",
        "agent_target": settings.openclaw_agent_target if is_remote else "",
        "primary_model": settings.openclaw_primary_model if is_remote else "",
        "live_ready": bool(is_remote and settings.openclaw_live_ready),
        "skills_discovered": bool(is_remote and settings.openclaw_skills_ready),
        "skill_status": skill_status,
         "skills": [
            {"name": "yusuchengjing-hotel-ops", "version": settings.openclaw_skill_version, "status": skill_status, "configured": settings.openclaw_skills_ready},
            {"name": "stayscape-product-generator", "version": settings.openclaw_skill_version, "status": skill_status, "configured": settings.openclaw_skills_ready},
            {"name": "stayscape-visitor-matcher", "version": settings.openclaw_skill_version, "status": skill_status, "configured": settings.openclaw_skills_ready},
            {"name": "stayscape-marketing-writer", "version": settings.openclaw_skill_version, "status": skill_status, "configured": settings.openclaw_skills_ready},
        ],
    }
